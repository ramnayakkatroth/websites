<?php
	$con=mysqli_connect("localhost","root","raghu68","tnp");
	if(!$con){
		echo "Not conne";
	}else{
		echo "conn";
	}
	echo "sdfsdf";
?>
