-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2018 at 05:34 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tnp`
--
CREATE DATABASE IF NOT EXISTS `tnp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tnp`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(250) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `role`, `date`) VALUES
('admin', 'admin@321', 'admin', '2018-12-11 17:51:12');

-- --------------------------------------------------------

--
-- Table structure for table `applied_list`
--

CREATE TABLE `applied_list` (
  `sid` varchar(10) NOT NULL,
  `cid` int(11) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `resume` varchar(250) NOT NULL,
  `jobOffer` varchar(250) NOT NULL,
  `highEducation` varchar(25) NOT NULL,
  `walkin_date` date NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applied_list`
--

INSERT INTO `applied_list` (`sid`, `cid`, `cname`, `resume`, `jobOffer`, `highEducation`, `walkin_date`, `date`) VALUES
('B141410', 7, 'Google', 'resumes/Google2018-12-21/B141410.docx', 'yes', 'no', '2018-12-21', '2018-12-12 15:13:37');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `cid` int(11) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `branch` varchar(250) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `ssc_yop` int(11) NOT NULL,
  `ssc_gpa` float NOT NULL,
  `puc_yop` int(11) NOT NULL,
  `puc_cgpa` float NOT NULL,
  `engg_cgpa` float NOT NULL,
  `no_of_backlogs` int(11) NOT NULL,
  `education_gap` int(11) NOT NULL,
  `date` date NOT NULL,
  `c_folder` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`cid`, `cname`, `branch`, `gender`, `ssc_yop`, `ssc_gpa`, `puc_yop`, `puc_cgpa`, `engg_cgpa`, `no_of_backlogs`, `education_gap`, `date`, `c_folder`) VALUES
(7, 'Google', 'CSE', 'both', 2014, 6, 2016, 7, 8, 0, 0, '2018-12-21', 'Google2018-12-21'),
(8, 'MicroSoft', 'CSE', 'both', 2014, 8, 2016, 8, 8, 0, 0, '2018-12-20', 'MicroSoft2018-12-20');

-- --------------------------------------------------------

--
-- Table structure for table `placed_list`
--

CREATE TABLE `placed_list` (
  `cid` int(11) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `sid` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `branch` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placed_list`
--

INSERT INTO `placed_list` (`cid`, `cname`, `sid`, `date`, `branch`) VALUES
(7, 'Google', 'B141410', '2018-12-21', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `sid` varchar(10) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `caste` varchar(10) NOT NULL,
  `marital_status` varchar(15) NOT NULL,
  `branch` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `ssc_yop` int(11) NOT NULL,
  `ssc_gpa` float NOT NULL,
  `ssc_school_name` varchar(250) NOT NULL,
  `ssc_type` varchar(250) NOT NULL,
  `ssc_g/p` varchar(50) NOT NULL,
  `ssc_medium` varchar(20) NOT NULL,
  `puc_yop` int(11) NOT NULL,
  `puc_cgpa` float NOT NULL,
  `e1_cgpa` float NOT NULL,
  `e2_cgpa` float NOT NULL,
  `e3_cgpa` float NOT NULL,
  `engg_cgpa` float NOT NULL,
  `no_of_backlogs` int(11) NOT NULL,
  `education_gap` int(11) NOT NULL,
  `education_gap_reason` text NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`sid`, `sname`, `fname`, `dob`, `gender`, `caste`, `marital_status`, `branch`, `password`, `ssc_yop`, `ssc_gpa`, `ssc_school_name`, `ssc_type`, `ssc_g/p`, `ssc_medium`, `puc_yop`, `puc_cgpa`, `e1_cgpa`, `e2_cgpa`, `e3_cgpa`, `engg_cgpa`, `no_of_backlogs`, `education_gap`, `education_gap_reason`, `email`, `mobile`, `address`) VALUES
('B141247', 'Ram Katroth', 'Ram', '1998-06-23', 'male', 'BC-D', 'Unmarried', 'ECE', 'rgukt', 2014, 9.7, 'Z.P.H.S Chekkapally', 'TS Regular', 'Govt.', 'English', 2016, 7.91, 8.35, 8.54, 8.8, 8.9, 0, 0, '', 'naveen@gmail.com', '9550806256', 'Chekkapally,Vemulawada,505302'),
('B141410', 'Naveen Gaddi', 'Ramulu Gaddi', '1998-06-23', 'male', 'BC-D', 'Unmarried', 'CSE', 'rgukt', 2014, 9.7, 'Z.P.H.S Chekkapally', 'TS Regular', 'Govt.', 'English', 2016, 7.91, 8.35, 8.54, 8.8, 8.9, 0, 0, '', 'naveen@gmail.com', '9550806256', 'Chekkapally,Vemulawada,505302');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `applied_list`
--
ALTER TABLE `applied_list`
  ADD PRIMARY KEY (`sid`,`cid`,`walkin_date`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `placed_list`
--
ALTER TABLE `placed_list`
  ADD PRIMARY KEY (`cid`,`sid`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
