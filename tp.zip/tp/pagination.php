<!DOCTYPE html>
<html>
<head>
	<title>Pagination</title>
</head>
<body>
<h1>pagination in php</h1>
<?php
$hostname = "localhost:3307";
$username = "root";
$password = "";
$database = "tnp";
$con = mysqli_connect("$hostname","$username","$password","$database") or die(mysqli_error());


?>
<?php
if(isset($_GET['page'])){
	$page=$_GET['page'];
}
else{
	$page=1;
}
if($page== '' || $page==1){
	$page1=0;

}
else{
	$page1=($page*5)-5;
}
$sql="SELECT * FROM notice ORDER BY date DESC LIMIT ".$page1.",10";
$data=$con->query($sql);
//print_r($data->fetch_all())
while($row =$data->fetch_assoc()){
	echo $row['title'].'<br>';
}
$sql="SELECT * FROM notice";
$data=$con->query($sql);
$records=$data->num_rows;
$records_pages=ceil($records/10);
$prev=$page-1;
$next=$page+1;
if( $prev>=1){
	echo "<a href='?page=".$prev."'>prev</a>"; 
}
if($records_pages >=2){
	for($r=1;$r<= $records_pages; $r++){
		echo "<a href='?page=".$r."'>".$r."</a>"; 
	}
}

if($next <= $records_pages && $records_pages >=2){
	echo "<a href='?page=".$next."'>NEXT</a>"; 
}
?>
</body>
</html>