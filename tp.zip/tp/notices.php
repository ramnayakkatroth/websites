<?php
include "./db.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placement Cell</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>

<body><br>
<div class="ui  container"><br><br>	
<div class="ui center aligned raised inverted blue segment">
	<h1>
	Notices & Updates</h1>
</div>

<?php
if(isset($_GET['page'])){
	$page=$_GET['page'];
}
else{
	$page=1;
}
if($page== '' || $page==1){
	$page1=0;

}
else{
	$page1=($page*10)-10;
}


$sql="SELECT * FROM notice ORDER BY date DESC LIMIT ".$page1.",10";
$data=$con->query($sql);
//print_r($data->fetch_all())
print('<div class="ui container" style="width:50em;">
		
					
					<div class="ui styled accordion">
					  
');
while($row =$data->fetch_assoc()){
	
	echo '<div class="title" style="color:black;">
					   <i class="user icon"></i>';
					   			echo $row['date']." ".$row['title'];
					echo ' </div>
					  <div class=" content">
					    <p class="ui green message transition hidden"> '.$row['discription'].'</p>
					    <a href="'.$row['file'].'" class="ui left floated tiny button ">File</a>';
					    ?><?php
					    	if($row['link']!=null){
					    		echo '<a href="'.$row['link'].'" class="ui right floated tiny button">URL link</a><br>';
					    	}
					  echo '</div>
					 ';
}
echo '</div>				
</div><br>';
$sql="SELECT * FROM notice";
$data=$con->query($sql);
$records=$data->num_rows;
$records_pages=ceil($records/10);
$prev=$page-1;
$next=$page+1;
echo "<center><div class='ui borderless  pagination menu' >";
if( $prev>=1){

	echo "<a class='item ' style='padding-right:2em' href='?page=".$prev."'>prev</a>"; 
}
if($records_pages >=2){
	for($r=1;$r<= $records_pages; $r++){
		echo "<a  class='item'   style='padding-left:2em' href='?page=".$r."'>".$r."</a>"; 
	}
}

if($next <= $records_pages && $records_pages >=2){
	echo "<a  class='item ' style='padding-left:2em' href='?page=".$next."'>NEXT</a>"; 
}
echo "</div></center>";


?>
	
</div>

<script type="text/javascript">
	$('.ui.accordion').accordion('refresh');
</script>
</html>