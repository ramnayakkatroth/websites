<?php
	include 'authenticate.php';
	if (isset($_SESSION['sid'])) {
		//echo $_SESSION['sid'];
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons menu" style="font-weight: bold;">
		<a href="index.php" class="item">Training & Placements Cell</a>
	
		
		<a href="about.php" class="right floated item"><b>About T & P</b></a>
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='profile.php' class='item'><b>Welcome! ".$_SESSION['sname']."</b></a>";
				echo "<a href='companies.php' class='item'><b>Walkins</b></a>";
				echo "<a href='contact.php' class='active item'><b>Contact Us</b></a>";
			?> 
			<a href="logout.php" class="item"><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='contact.php' class='active item'><b>Contact Us</b></a>";
				echo "<a href='login.php' class='item'><b>Student Login</b></a>";	
			}
		?>
	</div>
	<div class="ui raised segment container">
		<div class="ui blue piled segment header centered">Contact Info.</div>
		<div class="ui link stackable centered cards">
		  <div class="card">
		    <div class="image">
		      <img src="/images/avatar2/large/matthew.png">
		    </div>
		    <div class="content">
		      <div class="header">Matt Giampietro</div>
		      <div class="meta">
		        <a>Friends</a>
		      </div>
		      <div class="description">
		        Matthew is an interior designer living in New York.
		      </div>
		    </div>
		    <div class="extra content">
		      <span class="right floated">
		        Joined in 2013
		      </span>
		      <span>
		        <i class="user icon"></i>
		        75 Friends
		      </span>
		    </div>
		  </div>
		  <div class="card">
		    <div class="image">
		      <img src="/images/avatar2/large/matthew.png">
		    </div>
		    <div class="content">
		      <div class="header">Matt Giampietro</div>
		      <div class="meta">
		        <a>Friends</a>
		      </div>
		      <div class="description">
		        Matthew is an interior designer living in New York.
		      </div>
		    </div>
		    <div class="extra content">
		      <span class="right floated">
		        Joined in 2013
		      </span>
		      <span>
		        <i class="user icon"></i>
		        75 Friends
		      </span>
		    </div>
		  </div>
		  <div class="card">
		    <div class="image">
		      <img src="/images/avatar2/large/molly.png">
		    </div>
		    <div class="content">
		      <div class="header">Molly</div>
		      <div class="meta">
		        <span class="date">Coworker</span>
		      </div>
		      <div class="description">
		        Molly is a personal assistant living in Paris.
		      </div>
		    </div>
		    <div class="extra content">
		      <span class="right floated">
		        Joined in 2011
		      </span>
		      <span>
		        <i class="user icon"></i>
		        35 Friends
		      </span>
		    </div>
		  </div>
		  <div class="card">
		    <div class="image">
		      <img src="/images/avatar2/large/molly.png">
		    </div>
		    <div class="content">
		      <div class="header">Molly</div>
		      <div class="meta">
		        <span class="date">Coworker</span>
		      </div>
		      <div class="description">
		        Molly is a personal assistant living in Paris.
		      </div>
		    </div>
		    <div class="extra content">
		      <span class="right floated">
		        Joined in 2011
		      </span>
		      <span>
		        <i class="user icon"></i>
		        35 Friends
		      </span>
		    </div>
		  </div>
		  <div class="card">
		    <div class="image">
		      <img src="/images/avatar2/large/molly.png">
		    </div>
		    <div class="content">
		      <div class="header">Molly</div>
		      <div class="meta">
		        <span class="date">Coworker</span>
		      </div>
		      <div class="description">
		        Molly is a personal assistant living in Paris.
		      </div>
		    </div>
		    <div class="extra content">
		      <span class="right floated">
		        Joined in 2011
		      </span>
		      <span>
		        <i class="user icon"></i>
		        35 Friends
		      </span>
		    </div>
		  </div>
		  <div class="card">
		    <div class="image">
		      <img src="/images/avatar2/large/elyse.png">
		    </div>
		    <div class="content">
		      <div class="header">Elyse</div>
		      <div class="meta">
		        <a>Coworker</a>
		      </div>
		      <div class="description">
		        Elyse is a copywriter working in New York.
		      </div>
		    </div>
		    <div class="extra content">
		      <span class="right floated">
		        Joined in 2014
		      </span>
		      <span>
		        <i class="user icon"></i>
		        151 Friends
		      </span>
		    </div>
		  </div>
		</div>
	</div>
	<br><br><br><br>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>