<?php
	include 'authenticate.php';
	session_destroy();
	header("Location: index.php");
?>