<?php
	session_start();
	include 'db.php';
	if (isset($_POST['sid']) && isset($_POST['password'])) {
		$sid=$_POST['sid'];
		$password=$_POST['password'];
		$sql="select * from students where sid='$sid' and password='$password' ";
		$res=$con->query($sql);
		if ($res->num_rows>0) {
			$row=$res->fetch_assoc();
			$_SESSION['sid']=$sid;
			$_SESSION['sname']=$row['sname'];
			header("Location: index.php");
		}else{
			header("Location: login.php?log=0");
		}
	}
?>