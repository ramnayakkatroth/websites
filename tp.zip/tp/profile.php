<?php
	include 'authenticate.php';
	if (isset($_SESSION['sid'])) {
		//echo $_SESSION['sid'];
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons menu" style="font-weight: bold;">
		<a href="index.php" class="item"><i class="home icon"></i>Training & Placements Cell</a>
	
		
		<a href="about.php" class="right floated item"><i class="info circle icon"></i><b>About T & P</b></a>
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='profile.php' class='active item'><i class='user icon'></i><b>Welcome! ".$_SESSION['sname']."</b></a>";
				echo "<a href='companies.php' class='item'><i class='child icon'></i><b>Walkins</b></a>";
				echo "<a href='contact.php' class='item'><i class='phone icon'></i><b>Contact Us</b></a>";
			?> 
			<a href="logout.php" class="item"><i class="sign-out icon"></i><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='contact.php' class='active item'><b>Contact Us</b></a>";
				echo "<a href='login.php' class='item'><b>Student Login</b></a>";	
			}
		?>
	</div>
	<div class="ui raised segment container">
		<div class="ui two column stackable grid">
			 <div class="column">
			 	<img src="profile/B141410.jpg" alt="Profile Photo" class="ui medium circular right floated image">
			 </div>
			 <div class="left floated column">
			 	<br><br>
			 	<h1><?php 
			 		$sid=$_SESSION['sid'];
			 		$sql="select * from students where sid='".$sid."'";
			 		$res=$con->query($sql);
			 		$row=$res->fetch_assoc();
			 		echo "Student ID : ".$row['sid'];

			 	?></h1>
			 	
			 </div>

		</div>
		<div class="ui three column center aligned stackable grid">
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Profile</a>
		 				<div class="ui items">
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;<b>Name</b> &nbsp;: <?php echo $_SESSION['sname'];?></a>
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;<b>DOB</b>  &nbsp;&nbsp;&nbsp;: <?php echo $row['dob'];?></a>
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;<b>Branch</b>  : <?php echo $row['branch'];?></a>
		 				</div>
		 			
		 			</div>

		 		</div>
	 		</div>
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Offer Letters</a>
		 				<?php

		 					$sql="select * from placed_list where sid='".$sid."'";
		 					$rs=$con->query($sql);
		 					if($rs->num_rows>0){
		 						echo "<a class='item'>&nbsp;</a>";
		 						$rr=$rs->fetch_assoc();
		 						echo "<a class='item' style='color:green;'> Congrats You are Placed in ".$rr['cname']." held on ".$rr['date']."</a>";
		 					}else{
		 						echo "<a class='item'>&nbsp;&nbsp;&nbsp;&nbsp;</a>";
		 						echo "<a class='item' style='color:red;'>Sorry!. You haven't Placed</a>";
		 						echo "<a class='item'>&nbsp;&nbsp;&nbsp;&nbsp;</a>";
		 					}
		 				?>
		 				<div class="ui items">
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;</a>
		 					
		 				</div>
		 			</div>
		 		</div>
	 		</div>
	 		
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Contact</a>
		 				<div class="ui items">
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;<b>Mobile</b> &nbsp;: <?php echo $row['mobile'];?></a>
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;<b>E-mail</b>  &nbsp;&nbsp;&nbsp;: <?php echo $row['email'];?></a>
		 					<a class="item">&nbsp;&nbsp;&nbsp;&nbsp;</a>
		 				</div>
		 			</div>
		 		</div>
	 		</div>
		</div>
	</div>
	<div class="ui blue inverted raised segment header center aligned menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>