<?php
	include 'authenticate.php';
	if (isset($_SESSION['sid'])) {
		//echo $_SESSION['sid'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons menu" style="font-weight: bold;">
		<a href="index.php" class="item">Training & Placements Cell</a>
	
		
		<a href="about.php" class="right floated active item"><b>About T & P</b></a>
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='profile.php' class='item'><b>Welcome! ".$_SESSION['sname']."</b></a>";
				echo "<a href='companies.php' class='item'><b>Walkins</b></a>";
				echo "<a href='contact.php' class='item'><b>Contact Us</b></a>";
			?> 
			<a href="logout.php" class="item"><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='contact.php' class='item'><b>Contact Us</b></a>";
				echo "<a href='login.php' class='item'><b>Student Login</b></a>";	
			}
		?>
	</div>
	<div class="ui raised segment container">
		About Page Under Construction....
	</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>