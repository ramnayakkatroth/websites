<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell View List of Students</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>
	<?php
		if (isset($_REQUEST['add'])) {
			$a=$_REQUEST['add'];
			if ($a==1) {
				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Add Student Success....</div>
                        </div>";
			}else if($a==0){

				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Failed to Student already in Placed List....</div>
                        </div>";

			}
		}
	?>
		<div class="ui container">
			<form class="ui form" action="#" method="post">
				<input type="text" name='sid' placeholder="Please Enter Student ID">
				<button type="submit" class="ui blue button">Submit</button>
				
			</form>
				 <?php
				 	if (isset($_POST['sid'])) {
				 	?>
				 		<!-- <form class='ui form' method='post' action='genXL.php'>
                              <input type='hidden' name='sid' value="" />
                              <button class='ui green button' type='submit'>Export to XL</button>
                   			</form> -->
				 	<?php
				 	}
				 ?>
			
			<?php 
				if(isset($_POST['sid'])){
					echo "<div class='ui blue center aligned header segment'>Student ID ".$_POST['sid']."</div>";
			}?>
			<?php
					
				if(isset($_POST['sid'])){
						$sid=$_POST['sid'];
						//echo $sid;
						$sql="select * from placed_list where sid='".$sid."' ";
						$res=$con->query($sql);
						
						$c=1;
						if(!($res->num_rows>0)){
							echo "<p align='center'>Sorry! No record Found for bearing ID ".$sid."</p>";
						}else{
								echo "<table class='ui table'>";
								echo "<thead>";
								echo "<th>S.No.</th>";
								echo "<th>Company ID</th>";
								echo "<th>Company Name</th>";
								echo "<th>Student ID</th>";
								echo "<th>Walkin Date</th>";
								echo "<th>Action</th>";
								//echo "<th>Name of Recruiter</th>";
								echo "</thead>";
								while ($row=$res->fetch_assoc()) {

								echo "<tr><td>".$c++."</td><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['sid']."</td>

									<td>
										".$row['date']."
									</td>
									<td>
										<a href='profileS.php?sid=".$sid."' class='ui blue button'>Get Details</a>
										<a href='delete_S.php?sid=".$sid."' class='ui red button'>Delete</a>
									</td>
								</tr>";
								$flg=1;
							}
							echo "</table>";
						}
						


				}
					
			?>
		</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>
