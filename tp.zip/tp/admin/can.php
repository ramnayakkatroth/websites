    <?php
     
    $dataPoints = array(
    	array("label"=> "CSE", "y"=> 10),
    	array("label"=> "ECE", "y"=> 2),
    	array("label"=> "ME", "y"=> 4),
    	array("label"=> "CHEM", "y"=> 3),
    	array("label"=> "EEE", "y"=> 1),
    	array("label"=> "MME", "y"=> 573),
    	array("label"=> "CE", "y"=> 11)
    );
    	
    ?>
    <!DOCTYPE HTML>
    <html>
    <head>  
    <script>
    window.onload = function () {
     
    var chart = new CanvasJS.Chart("chartContainer", {
    	animationEnabled: true,
    	exportEnabled: true,
    	title:{
    		text: "Student Placed in All Branches"
    	},
 
    	subtitles: [{
    		text: "Currency Used: Thai Baht (฿)"
    	}],
    	data: [{
    		type: "pie",
    		showInLegend: "true",
    		legendText: "{label}",
    		indexLabelFontSize: 16,
    		yValueFormatString: "฿#,##0",
    		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
    	}]
    });
    chart.render();
     
    }
    </script>
    </head>
    <body>
    <div id="chartContainer" style="height: 370px; width: 100%;"></div>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    </body>
    </html>                              