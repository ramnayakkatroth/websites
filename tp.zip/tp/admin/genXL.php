<?php
	if (isset($_SESSION['username'])) {
		
	}
	if (isset($_POST['name']) && isset($_POST['year'])) {
		include 'db.php';
		$name=$_POST['name'];
		
		$year=$_POST['year'];
			
		//echo $year.$name;
		
		header('Content-Disposition: attachment;filename='.$name.'.xls');
		header('Cache-Control:no-cache,no-store,must-revalidate,post-check=0,pre-check=0');
		header('Pragma:no-cache');
		header('Content-Type:application/x-msexcel;charset=windows-1251;format=attachment;');
		$sql="select * from placed_list where date like '%$year%' ";
		$res=$con->query($sql);
		if ($res->num_rows>0) {
				$cols=mysqli_num_fields($res);
				$m="<table><thead><tr><td>S.No</td>";
				while ($prop=$res->fetch_field()) {
					$m.="<td>";
					$m.=$prop->name;
					$m.="</td>";
				}
			$m.="</tr></thead><tbody>";
			$i=0;$c=1;
			while ($row=$res->fetch_array()) {
				$m.="<tr><td>".$c."</td>";
				for ($i=0; $i <$cols ; $i++) { 
					$val=$row[$i];
					$m.="<td>".$val."</td>";
				}
				$c++;
				$m.="</tr>";
			}
			$m.="</tbody></table>";
			echo $m;
		}
	}
?>

