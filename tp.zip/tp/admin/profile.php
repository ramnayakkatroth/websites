<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		//echo $_SESSION['sid'];
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons menu" style="font-weight: bold;">
		<a href="index.php" class="item">Admin Home</a>
	
		
		<a href="../about.php" class="right floated item"><b>About T & P</b></a>
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='profile.php' class='active item'><b>Welcome! ".$_SESSION['username']."</b></a>";
				echo "<a href='../companies.php' class='item'><b>Walkins</b></a>";
				echo "<a href='../contact.php' class='item'><b>Contact Us</b></a>";
			?> 
			<a href="logout.php" class="item"><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='../contact.php' class='active item'><b>Contact Us</b></a>";
				echo "<a href='login.php' class='item'><b>Admin Login</b></a>";	
			}
		?>
	</div>
	<div class="ui raised segment container">
		<div class="ui two column stackable grid">
			 <div class="column">
			 	<img src="profile/B141410.jpg" alt="Profile Photo" class="ui medium circular right floated image">
			 </div>
			 <div class="left floated column">
			 	<br><br>
			 	<h1><?php echo $_SESSION['username'];?></h1>
			 	<div class="meta">Administrator...</div>
			 </div>
		</div>
		<div class="ui four column center aligned stackable grid">
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Profile</a>
		 			</div>
		 		</div>
	 		</div>
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Offer Letters</a>
		 			</div>
		 		</div>
	 		</div>
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Notices</a>
		 			</div>
		 		</div>
	 		</div>
	 		<div class="column">
	 			<div class="ui cards">
		 			<div class="ui raised card">
		 				<a href="#" class="ui big circular button">Contact</a>
		 			</div>
		 		</div>
	 		</div>
		</div>
	</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>