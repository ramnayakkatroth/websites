class a extends Parent implements Interface {
	public static void main(String[] args) {
		
	}
}