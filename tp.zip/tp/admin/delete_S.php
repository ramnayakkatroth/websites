<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		if (isset($_GET['sid'])) {
			$sid=$_GET['sid'];
			$sql="delete from placed_list where sid='".$sid."'";
			$res=1;
			$res=$con->query($sql);
			if($res){
				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Student ".$sid." Record Deleted</div>
                        </div>";
			}else{
				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Oops some error occured!...</div>
                        </div>";
			}
		}
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell View List of Students</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>
	
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>
