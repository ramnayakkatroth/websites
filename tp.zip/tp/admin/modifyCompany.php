<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell Modify Companies</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>

		<div class="ui container">
			<div class="ui blue center aligned header segment">List Of Walkins</div>
			<?php
					$sql="select * from companies order by date desc";
					$res=$con->query($sql);
					echo "<table class='ui table'>";
					echo "<thead>";
					echo "<th>Company ID</th>";
					echo "<th>Company Name</th>";
					echo "<th>Walkin Date</th>";
					echo "<th>Action</th>";
					echo "</thead>";
					while ($row=$res->fetch_assoc()) {
						echo "<tr><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['date']."</td>

							<td>
								<form action='modify.php' method='post'>
									<input type='hidden' name='cid' value=".$row['cid']." >
									<button type='submit' class='ui orange button'>Modify</button>
								</form>
							</td>

						</tr>";
					}
					echo "</table>";
			?>
		</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
	<script type="text/javascript">
		$('.ui.dropdown').dropdown();
	</script>
</body>
</html>