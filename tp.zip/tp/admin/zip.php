<?php include '../db.php';?>
<form method="post" action="#">
    <?php 
    $sql="SELECT * from companies";
    $res=$con->query($sql);
    echo '<select name="folder">';
    if(mysqli_num_rows($res) >0){
        while($row=mysqli_fetch_assoc($res)){
           echo '<option  value='.$row['c_folder'].'>'.$row['c_folder'].'</option>';
        }
    }
    echo "</select>";
    ?>
    <input type="submit" name="test" id="test" value="RUN" /><br/>
</form>

<?php
function create()
{
	if(isset($_POST['test'])){
        $rootPath = realpath("../resumes/".$_POST['folder']);
    }

$zip = new ZipArchive();
$zip->open(''.$rootPath.'.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE);


$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($rootPath),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $name => $file)
{
    // Skip directories (they would be added automatically)
    if (!$file->isDir())
    {
        // Get real and relative path for current file
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($rootPath) + 1);

        // Add current file to archive
        $zip->addFile($filePath, $relativePath);

    }

}

// Zip archive will be created only after closing object
$zip->close();
header('Content-disposition: attachment; filename='.$rootPath.'.zip');
        header("Content-Transfer-Encoding: binary");
        header('Content-type: application/zip');

        readfile($rootPath.".zip");

}

if(array_key_exists('test',$_POST)){
   create();
   echo "Created Zip Successfully";
}

?>
