<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell View List of Students</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>
	<?php
		if (isset($_REQUEST['add'])) {
			$a=$_REQUEST['add'];
			if ($a==1) {
				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Add Student Success....</div>
                        </div>";
			}else if($a==0){

				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Failed to Student already in Placed List....</div>
                        </div>";

			}
		}
	?>
		<div class="ui container">
			<form action="#" method="post">
				<input type="number" min=2000 max=2099 name="date" placeholder="Please Enter Year">
				<?php 
					$y=date("Y",strtotime(date("Y")));
					if (isset($_POST['date'])) {
						
						$y=$_POST['date'];
					}
				?>
				<button type="submit" class="ui blue button">Submit</button>
				
			</form>
			<div class="ui blue center aligned header segment">Add Student to Placed List in <?php echo $y;?> </div>
			<?php
					

					$sql="select * from applied_list where date like '%$y%' and sid not in (select sid from placed_list)";
					$res=$con->query($sql);
					echo "<table class='ui table'>";
					echo "<thead>";
					echo "<th>Company ID</th>";
					echo "<th>Company Name</th>";
					echo "<th>Student ID</th>";
					echo "<th>Action</th>";
					echo "</thead>";
					while ($row=$res->fetch_assoc()) {
						echo "<tr><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['sid']."</td>

							<td>
								<form action='addSP.php' method='post'>
									<input type='hidden' name='cid' value=".$row['cid'].">
									<input type='hidden' name='cname' value=".$row['cname'].">
									<input type='hidden' name='sid' value=".$row['sid'].">
									<input type='hidden' name='date' value=".$row['walkin_date'].">
									<button type='submit' class='ui green button'>Add</button>
								</form>
							</td>
						</tr>";
					}
					echo "</table>";
			?>
		</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>