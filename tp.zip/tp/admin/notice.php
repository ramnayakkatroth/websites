<?php
include './db.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placement Cell</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<style type="text/css">
	input{
		width: 2em;
	}
</style>
<body>
<div class="ui container"><br><br>	
<div class="ui center aligned raised inverted blue segment">
	<h1>
	Notices Uploding</h1>
</div>
<form method="post" action="#" enctype="multipart/form-data" class="ui stacked bolded raised segment header form" style="width: 60em">
	Title &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="title" required  ><br><br>
	Description &nbsp;&nbsp;<textarea name="desc" ></textarea><br><br>
	File &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="file" class="ui red  button" name="file1" > <br><br><br>
	<button type="submit" name="sub"> Submit </button>
</form>
</div>
</body>
</html>
<?php

if(isset($_POST['sub']) && isset($_FILES['file1'])){
	$file1=$_FILES['file1']['name'];
	$file2=$_FILES['file1']['tmp_name'];
	$fsize=$_FILES['file1']['size'];
	$title=$_POST['title'];
	$descc=$_POST['desc'];
	$path="../notices/".$file1;
	if($fsize > 2097152){
         echo '<h1>File size must be exactely 2 MB</h1>';
      }
	if(file_exists($path)){
			echo "<h1> already Uploaded</h1>";
		}
	else{
		$sql="INSERT INTO notice (title,discription,file,n_folder) values ('$title','$descc' ,'$file1','../notices/')";
		$rr=$con->query($sql);
		move_uploaded_file($file2,"../notices/".$file1);
		echo "<div class='ui green message'>SUCEESS</div>";
		}
	
	
}



?>