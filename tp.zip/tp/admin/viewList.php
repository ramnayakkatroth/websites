<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell View List of Students</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>

		<div class="ui container">
			<div class="ui blue center aligned header segment">List Of Students </div>
			<?php
					if (isset($_POST['cid'])) {
						# code...
					}else{
						header("Location: viewCompanies.php");
					}
					$cid=$_POST['cid'];

					$sql="select *,count(*) c from applied_list where cid=$cid ";
					$res=$con->query($sql);
					//echo "<p>Total Students Applied: ".$['c']." ";
					echo "<table class='ui table'>";
					echo "<thead>";
					echo "<th>S.No</th>";
					echo "<th>Company ID</th>";
					echo "<th>Company Name</th>";
					echo "<th>Student ID</th>";
					echo "<th>Resume</th>";
					echo "</thead>";
					$c=1;
					while ($row=$res->fetch_assoc()) {
						echo "<tr><td>".$c."</td><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['sid']."</td>

							<td>
								<a href='../".$row['resume']."'><button class='ui blue button'>Download</button></a>
							</td>
						</tr>";
						$c++;
					}
					echo "</table>";
			?>
		</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>