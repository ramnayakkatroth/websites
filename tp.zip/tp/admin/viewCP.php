<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>
	
		<div class="ui container">
			<form action="#" method="post">
				<input type="number" min=2000 max=2099 name="date" placeholder="Please Enter Year">
				<?php 
					$y=date("Y",strtotime(date("Y")));
					if (isset($_POST['date'])) {
						
						$y=$_POST['date'];
					}
				?>
				<button type="submit" class="ui blue button">Submit</button>
			</form>

			 	<form class='ui form' method='post' action='genXL_C.php'>
                                        <input type='hidden' name='year' value=<?php echo $y;?> />
                                        <input type='hidden' name='name' value=<?php echo $y.'Placed_Company_Wise';?> />
                                        <button class='ui green button' type='submit'>Export to XL</button>
                                </form>

			<div class="ui blue center aligned header segment">Company Wise Data Students Placed in Year <?php echo $y;?></div>

			<?php
					

					$sql="select *,count(*) from placed_list group by cid having date like '%$y%'";
					$res=$con->query($sql);
					echo "<table class='ui table'>";
					echo "<thead>";
					echo "<th>S.No.</th>";
					echo "<th>Company ID</th>";
					echo "<th>Company Name</th>";
					echo "<th>Walkin Date</th>";
					echo "<th>Salary</th>";
					//echo "<th>Branch</th>";
					echo "<th>No.of Students Placed</th>";
					echo "<th>Sector</th>";
					echo "<th>Year</th>";
					//echo "<th>Name of Recruiter</th>";
					echo "</thead>";
					$c=1;
					while ($row=$res->fetch_assoc()) {
						$arr=explode("-", $row['date']);


						echo "<tr><td>".$c++."</td><td>".$row['cid']."</td><td>".$row['cname']."</td>

							<td>".$row['date']."</td><td>--</td><td>".$row['count(*)']."</td>

							<td>--</td><td>".$arr[0]."</td>
						</tr>";
						
					}
					echo "</table>";
			?>
		</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>
