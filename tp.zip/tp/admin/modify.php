<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
			if (isset($_POST['cname']) && isset($_POST['branch']) && isset($_POST['gender']) && isset($_POST['ssc_yop']) && isset($_POST['ssc_gpa']) && isset($_POST['puc_yop']) && isset($_POST['puc_cgpa']) && isset($_POST['engg_cgpa']) && isset($_POST['no_of_backlogs']) && isset($_POST['education_gap'])) {
				
				//echo "ok";
				$cid=$_POST['cid'];
				$cname=$_POST['cname'];
				$branch=$_POST['branch'];
				$br=implode(",", $branch);
				$gender=$_POST['gender'];
				$ssc_yop=$_POST['ssc_yop'];
				$ssc_gpa=$_POST['ssc_gpa'];
				$puc_yop=$_POST['puc_yop'];
				$puc_cgpa=$_POST['puc_cgpa'];
				$engg_cgpa=$_POST['engg_cgpa'];
				$no_of_backlogs=$_POST['no_of_backlogs'];
				$education_gap=$_POST['education_gap'];
				$date=$_POST['date'];
				//print_r($br);
				$dir=$cname.$date;
				//creatin directory for walkin
				if(!file_exists("../resumes/".$dir."")){
					mkdir("../resumes/".$dir."");
				}
				$sql="UPDATE `companies` SET `cname`='$cname',`branch`='$br',`gender`='$gender',`ssc_yop`=$ssc_yop,`ssc_gpa`=$ssc_gpa,`puc_yop`=$puc_yop,`puc_cgpa`=$puc_cgpa,`engg_cgpa`=$engg_cgpa,`no_of_backlogs`=$no_of_backlogs,`education_gap`=$education_gap,`date`='$date',`c_folder`='$dir' WHERE cid=$cid";

				//echo $sql;
					$res=$con->query($sql);
					if ($res) {
							echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Details Update Success....</div>
                        </div>";
					}else{
							echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Failed to Update</div>
                        </div>";
					}
				//print($date);


			}

	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>T & P Cell Modify Companies</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>

		<div class="ui container">
			<div class="ui blue center aligned header segment">List Of Walkins</div>
			<?php
					if (isset($_POST['cid'])) {
						$cid=$_POST['cid'];

						$sql="select * from companies where cid=$cid";

						$res=$con->query($sql);
						if ($res->num_rows>0) {
								while ($row=$res->fetch_assoc()) {
										?>
											<div class="ui two column center alinged stackable grid">
												<div class="column">
													<div class="ui raised segment centered">
														<div class="ui blue segment header centered">Modify Company...</div>
														<form action="#" class="ui form" method="post">
															<label>Company Name : </label>
															<input type="hidden" name="cid" value="<?php echo $row['cid'];?>" >
															<input type="text" name="cname" value="<?php echo $row['cname'];?>" required><br><br>
															<label>Branch : </label>
															<select name="branch[]" multiple class="ui dropdown" required>
																<option value="CE">CE</option>
																<option value="CHEM">CHEM</option>
																<option value="CSE">CSE</option>
																<option value="ECE">ECE</option>
																<option value="EEE">EEE</option>
																<option value="ME">ME</option>
																<option value="MME">MME</option>
															</select><br><br>

															<label>Gender : </label><br>
															<label>Male&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
															<input type="radio" name="gender" value="male" required><br>
															<label>Female&nbsp;</label>
															<input type="radio" name="gender" value="female"><br>
															<label>Both&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
															<input type="radio" name="gender" value="both"><br><br>

															<label>SSC Year of Pass : </label>
															<input type="number" name="ssc_yop" value="<?php echo $row['ssc_yop'];?>" min=2000 placeholder="Enter Required SSC Year" required><br><br>

															<label>SSC GPA (EX: 9.5) : </label>
															<input type="number" name="ssc_gpa" value="<?php echo $row['ssc_gpa'];?>" min=0 max=10 step=0.1 placeholder="Enter Required SSC GPA" required><br><br>

															<label>PUC Year of Pass : </label>
															<input type="number" name="puc_yop" min=2000 value="<?php echo $row['puc_yop'];?>" placeholder="Enter Required PUC Year" required><br><br>

															<label>PUC CGPA (Ex:8.54) : </label>
															<input type="number" name="puc_cgpa" min=0  value="<?php echo $row['puc_cgpa'];?>" max=10 step=0.01 placeholder="Enter Required PUC CGPA" required><br><br>

															<label>Engg CGPA (Ex: 8.64) : </label>
															<input type="number" name="engg_cgpa" min=0 max=10 step=0.01 value="<?php echo $row['engg_cgpa'];?>" placeholder="Enter Required Engg CGPA" required><br><br>

															<label>No of Backlogs : </label>
															<input type="number" name="no_of_backlogs" min=0 value="<?php echo $row['no_of_backlogs'];?>" placeholder="Enter if Backlogs allowed"  value="0" required><br><br>

															<label>Education Gap( in no.of Years) : </label>
															<input type="number" name="education_gap" min=0 value="<?php echo $row['education_gap'];?>" placeholder="Enter if Education gap allowed"  value="0" required><br><br>
															<label>Date of Walkin</label>
															<input type="date" name="date" value="<?php echo $row['date'];?>" placeholder="select Walkin Date" required><br><br>
															<button class="ui orange button" type="Submit">Update</button>

															<br><br><br><br>
														</form>
													</div>
												</div>
												
											</div>

										<?php	
								}
						}else{
							echo "NO Data";
						}

					}else{
						header("Location: modifyCompanies.php");
					}
			?>
		</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
	<script type="text/javascript">
		$('.ui.dropdown').dropdown();
	</script>
</body>
</html>