<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		# code...
			if(isset($_POST['cid']) && isset($_POST['cname']) && isset($_POST['sid']) && isset($_POST['date']) ){
				$cid=$_POST['cid'];
				$cname=$_POST['cname'];
				$sid=$_POST['sid'];
				$date=$_POST['date'];
				$sql="select * from students where sid='$sid'";
				$res=$con->query($sql);
				$row=$res->fetch_assoc();
				$branch=$row['branch'];
				$sql="insert into placed_list (cid,cname,sid,date,branch) values($cid,'$cname','$sid','$date','$branch')";
				$res=$con->query($sql);
				if ($res) {
					header("Location: addStudent.php?add=1");
				}else{
					header("Location: addStudent.php?add=0");
				}

			}
	}else{
		header("Location: login.php");
	}
	
?>