<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		//echo $_SESSION['sid'];
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Welcome! Admin</div> -->
	<div class="ui inverted blue menu">
		<a href="index.php" class="item"><i class="home icon"></i> Welcome! Administrator</a>
	
		
		<a href="about.php" class="right floated item"><i class="info circle icon"></i><b>About</b></a>
		<a href="logout.php" class="item"><i class="sign-out icon"></i><b>Logout</b></a>

	</div>
		<div class="ui three column stackable grid container">
			<div class="column">
				<div class="ui piled segment">
					<div class="ui blue segment center aligned header">Companies</div>
					<div class="ui items">
						<a href="addCompany.php" class="item"><button class="ui green button"><i class="plus icon"></i>Add Company&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						<a href="viewCompanies.php" class="item"><button class="ui blue button"><i class="eye icon"></i>View Companies&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						<a href="modifyCompany.php" class="item"><button class="ui orange button">+/- Modify Company &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
					</div>
				</div>
			</div>
			<div class="column">
				<div class="ui piled segment">
					<div class="ui blue segment center aligned header">Student</div>
					<div class="ui items">
						<a class="item" href="viewCompanies.php"><button class="ui violet button"><i class="eye	 icon"></i>View Students by Company wise </button></a>
						<a class="item" href="listStudents.php"><button class="ui yellow button"><i class="eye icon"></i>View Students&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						<a class="item" href="addStudent.php"><button class="ui green button"><i class="plus icon"></i> Add Student to Placed List&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						<a class="item" href="searchS.php"><button class="ui teal button"><i class="search icon"></i> Search Student&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>

					</div>
				</div>
			</div>
			<div class="column">
				<div class="ui piled segment">
					<div class="ui blue segment center aligned header">Statistics</div>
					<div class="ui items">
						<a class="item" href="viewSP.php"><button class="ui blue button">View No.of Students Placed&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </button></a>
						<a class="item" href="viewCP.php"><button class="ui grey button">Company Wise&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						<a class="item" href="viewBR.php"><button class="ui brown button">Branch Wise&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						

					</div>
				</div>
			</div>
			<div class="column">
				
			</div>
			<div class="column">
				<div class="ui piled segment">
					<div class="ui blue segment center aligned header">Events</div>
					<div class="ui items">
						<a class="item" href="#"><button class="ui blue button">Add News & Events&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </button></a>
						<a class="item" href="#"><button class="ui grey button">Add Company Schedule&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
						<a class="item" href="#"><button class="ui brown button">Latest Updates&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
					</div>
				</div>
			</div>
			<div class="column">
				
			</div>
		</div>
	<div class="ui blue inverted raised segment header center aligned menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>
