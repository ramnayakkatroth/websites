<?php
	include 'authenticate.php';
	if (isset($_SESSION['username'])) {
		//echo $_SESSION['sid'];
			if (isset($_POST['cname']) && isset($_POST['branch']) && isset($_POST['gender']) && isset($_POST['ssc_yop']) && isset($_POST['ssc_gpa']) && isset($_POST['puc_yop']) && isset($_POST['puc_cgpa']) && isset($_POST['engg_cgpa']) && isset($_POST['no_of_backlogs']) && isset($_POST['education_gap'])) {
				
				//echo "ok";
				$cname=$_POST['cname'];
				$branch=$_POST['branch'];
				$br=implode(",", $branch);
				$gender=$_POST['gender'];
				$ssc_yop=$_POST['ssc_yop'];
				$ssc_gpa=$_POST['ssc_gpa'];
				$puc_yop=$_POST['puc_yop'];
				$puc_cgpa=$_POST['puc_cgpa'];
				$engg_cgpa=$_POST['engg_cgpa'];
				$no_of_backlogs=$_POST['no_of_backlogs'];
				$education_gap=$_POST['education_gap'];
				$date=$_POST['date'];
				//print_r($br);
				$dir=$cname.$date;
				//creatin directory for walkin
				mkdir("../resumes/".$dir."");
				$sql="INSERT INTO `companies`( `cname`, `branch`, `gender`, `ssc_yop`, `ssc_gpa`, `puc_yop`, `puc_cgpa`, `engg_cgpa`, `no_of_backlogs`, `education_gap`, `date`, `c_folder`) VALUES ('$cname','$br','$gender',$ssc_yop,$ssc_gpa,$puc_yop,$puc_cgpa,$engg_cgpa,$no_of_backlogs,$education_gap,'$date','$dir')";

				//echo $sql;
					$res=$con->query($sql);
					if ($res) {
							echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Success....</div>
                        </div>";
					}else{
							echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Failed to Add Company</div>
                        </div>";
					}
				//print($date);


			}
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Welcome! Admin</div> -->
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Welcome! Administrator</a>
		
		
		<a href="about.php" class="right floated item"><b>About</b></a>
		<a href="logout.php" class="item"><b>Logout</b></a>

	</div>
		<div class="ui container">
			<div class="ui stackable grid">
				<div class="column">
					<div class="ui raised segment centered">
						<div class="ui blue segment header centered"><b>Add Company...</b></div>
						<form action="#" class="ui form" method="post">
							<label><b>Company Name : </b></label>
							<input type="text" name="cname" placeholder="Enter Company Name" required><br><br>
							<label><b>Branch : </b></label>
							<select name="branch[]" multiple class="ui dropdown" required>
								<option value="CE">CE</option>
								<option value="CHEM">CHEM</option>
								<option value="CSE">CSE</option>
								<option value="ECE">ECE</option>
								<option value="EEE">EEE</option>
								<option value="ME">ME</option>
								<option value="MME">MME</option>
							</select><br><br>

							<label><b>Gender : </b></label><br>
							<label>Male&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
							<input type="radio" name="gender" value="male" required><br>
							<label>Female&nbsp;</label>
							<input type="radio" name="gender" value="female"><br>
							<label>Both&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
							<input type="radio" name="gender" value="both"><br><br>

							<label><b>SSC Year of Pass : </b></label>
							<input type="number" name="ssc_yop" min=2000 placeholder="Enter Required SSC Year" required><br><br>

							<label><b>SSC GPA (EX: 9.5) : </b></label>
							<input type="number" name="ssc_gpa" min=0 max=10 step=0.1 placeholder="Enter Required SSC GPA" required><br><br>

							<label><b>PUC Year of Pass : </b></label>
							<input type="number" name="puc_yop" min=2000 placeholder="Enter Required PUC Year" required><br><br>

							<label><b>PUC CGPA (Ex:8.54) : </b></label>
							<input type="number" name="puc_cgpa" min=0 max=10 step=0.01 placeholder="Enter Required PUC CGPA" required><br><br>

							<label><b>Engg CGPA (Ex: 8.64) : </b></label>
							<input type="number" name="engg_cgpa" min=0 max=10 step=0.01 placeholder="Enter Required Engg CGPA" required><br><br>

							<label><b>No of Backlogs : </b></label>
							<input type="number" name="no_of_backlogs" min=0 placeholder="Enter if Backlogs allowed"  value="0" required><br><br>

							<label><b>Education Gap( in no.of Years) :</b> </label>
							<input type="number" name="education_gap" min=0 placeholder="Enter if Education gap allowed"  value="0" required><br><br>
							<label><b>Date of Walkin</b></label>
							<input type="date" name="date" placeholder="select Walkin Date" required><br><br>
							<button class="ui blue button" type="Submit">Submit</button>

							<br><br><br><br>
						</form>
					</div>
				</div>
				
			</div>
	</div>
</center>
	<div class="ui blue inverted raised segment header center aligned menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
	<script type="text/javascript">
		$('.ui.dropdown').dropdown();
	</script>
</body>
</html>
