<?php
	error_reporting(E_ALL | E_STRICT);
	ini_set('display_errors','on');


	//mkdir("../resumes/g",0777,true);
	$out=exec("mkdir g");
	echo $out;
?>
