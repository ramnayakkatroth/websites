<?php
	session_start();
	include 'db.php';
	if (isset($_POST['username']) && isset($_POST['password'])) {
		$username=$_POST['username'];
		$password=$_POST['password'];
		$sql="select * from admin where username='$username' and password='$password' ";
		$res=$con->query($sql);
		if ($res->num_rows>0) {
			$row=$res->fetch_assoc();
			$_SESSION['username']=$username;
			$_SESSION['role']=$row['role'];
			header("Location: index.php");
		}else{
			header("Location: login.php?log=0");
		}
	}
?>