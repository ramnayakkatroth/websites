<?php
	if (isset($_SESSION['username'])) {
		
	}
	if (isset($_POST['name']) && isset($_POST['year'])) {
		include 'db.php';
		$name=$_POST['name'];
		
		$year=$_POST['year'];
			
		//echo $year.$name;
		
		header('Content-Disposition: attachment;filename='.$name.'.xls');
		header('Cache-Control:no-cache,no-store,must-revalidate,post-check=0,pre-check=0');
		header('Pragma:no-cache');
		header('Content-Type:application/x-msexcel;charset=windows-1251;format=attachment;');
			$sql="select *,count(*) from placed_list group by cid having date like '%$y%'";
					$res=$con->query($sql);
					echo "<table class='ui table'>";
					echo "<thead>";
					echo "<th>S.No.</th>";
					echo "<th>Company ID</th>";
					echo "<th>Company Name</th>";
					echo "<th>Walkin Date</th>";
					echo "<th>Salary</th>";
					//echo "<th>Branch</th>";
					echo "<th>No.of Students Placed</th>";
					echo "<th>Sector</th>";
					echo "<th>Year</th>";
					//echo "<th>Name of Recruiter</th>";
					echo "</thead>";
					$c=1;
					while ($row=$res->fetch_assoc()) {
						$arr=explode("-", $row['date']);


						echo "<tr><td>".$c++."</td><td>".$row['cid']."</td><td>".$row['cname']."</td>

							<td>".$row['date']."</td><td>--</td><td>".$row['count(*)']."</td>

							<td>--</td><td>".$arr[0]."</td>
						</tr>";
						
					}
					echo "</table>";

	}
?>

