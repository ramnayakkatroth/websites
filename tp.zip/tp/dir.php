<?php
	//mkdir("../resumes/g",0777);
	exec("mkdir ms");
?>
