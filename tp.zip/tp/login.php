<?php
/*
	include 'authenticate.php';
	if (isset($_SESSION['sid'])) {
		header("Location: index.php");
	}
	if (isset($_REQUEST['log'])) {
	 		if ($_REQUEST['log']==0) {
	 		 		 echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Invalid Login..... </div>
                        </div>";
	 		 } 
	}
*/
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons menu">
		<a href="index.php" class="item">Training & Placements Cell</a>
		<a href="index.php" class="right floated item"><b>Home</b></a>
		<a href="#" class="active item"><b>Student Login</b></a>
		<a href="about.php" class="item"><b>About</b></a>
	</div>
	<div class="ui container">
		<div class="ui three column grid">
			<div class="column">
				
			</div>
			<div class="column">
				<div class="ui raised segment">
					<div class="ui blue inverted piled segment center aligned">Student Login</div>
					<form class="ui form" method="post" action="authenticate.php"> 
						<label><b>Student ID</label>
						<input type="text" name="sid" placeholder="Student ID No."><br><br>
						<label>Password</b></label>
						<input type="password" name="password" placeholder="Password"><br><br>
						<button type="submit" name="submit" value="submit" class="ui blue button">Login</button>
						<a href="forgot.php" class="item">Forgot Password</a>
					</form>
				</div>
			</div>
			<div class="column">
				
			</div>
		</div>
	</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>
