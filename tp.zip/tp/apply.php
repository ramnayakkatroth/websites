<?php
	include 'authenticate.php';
	if (isset($_SESSION['sid']) && isset($_POST['cid'])) {
		//echo $_SESSION['sid'];
		if (isset($_POST['cid']) && isset($_POST['cname']) && isset($_POST['jobOffer']) && isset($_POST['highEducation']) && isset($_FILES['resume'])) {
			$file_name = $_FILES['resume']['name'];
			$file_tmp = $_FILES['resume']['tmp_name'];
			$sid=$_SESSION['sid'];
			$arr=explode(".", $file_name);
			$fname=$sid.".".$arr[1];
			$cid=$_POST['cid'];
			$cname=$_POST['cname'];
			$jobOffer=$_POST['jobOffer'];
			$highEducation=$_POST['highEducation'];
			$c_folder=$_POST['c_folder'];
			$walkin_date=$_POST['walkin_date'];

			/*echo $sid."<br>";
			echo $cid."<br>";
			echo $cname."<br>";
			echo $fname."<br>";
			echo $jobOffer."<br>";
			echo $highEducation."<br>";
			echo $c_folder;*/

			//move_uploaded_file($file_tmp, $cname)
			$sql="insert into applied_list(sid,cid,cname,resume,jobOffer,highEducation,walkin_date)values('$sid',$cid,'$cname','resumes/".$c_folder."/$fname','$jobOffer','$highEducation','$walkin_date')";

			//echo $sql;
			$res=$con->query($sql);
			if ($res) {
					$path="resumes/".$c_folder."/".$fname;
					move_uploaded_file($file_tmp, $path);
				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Success</div>
                        </div>";
			}else{
				 echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Already Applied..... </div>
                        </div>";
			}
		}
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons menu" style="font-weight: bold;">
		<a href="index.php" class="item">Training & Placements Cell</a>
	
		
		<a href="about.php" class="right floated item"><b>About T & P</b></a>
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='#' class='item'><b>Welcome! ".$_SESSION['sname']."</b></a>";
				echo "<a href='companies.php' class='item'><b>Walkins</b></a>";
			?> 
			<a href="logout.php" class="item"><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='login.php' class='item'><b>Student Login</b></a>";	
			}
		?>
	</div>
	<div class="ui container centered">
			<div class="ui two column center alinged centered stackable grid">
				<div class="column">
					<div class="ui raised segment">
						<div class="ui blue segment header centered">Apply for <?php echo $_POST['cname'];?></div>
						<form action="#" class="ui form" method="post" enctype = "multipart/form-data">
							<label><b>Student ID : <?php echo $_SESSION['sid'];?></label><br><br>
							<label>Company ID : <?php echo $_POST['cid'];?></label><br><br>
							<label>Company Name : <?php echo $_POST['cname'];?></label><br><br>
							<input type="hidden" name="cid" value=<?php echo $_POST['cid']?> >
							<input type="hidden" name="cname" value=<?php echo $_POST['cname']?> >
							<input type="hidden" name="c_folder" value=<?php echo $_POST['c_folder']?> >
							<input type="hidden" name="walkin_date" value=<?php echo $_POST['walkin_date']?> >
							<label>Upload Resume</label><br><br>
							<input type="file" name="resume" placeholder="Please Upload Resume" required><br><br>
							<label>Any Job Offer Before?</label><br><br>
							<select name="jobOffer" required class="ui dropdown">
								<option >Select Yes/No</option>
								<option value="yes">Yes</option>
								<option value="no">No</option>
							</select><br><br>
							<label>Any Higher Education Offer Before?</label><br><br>
							<select name="highEducation" required class="ui dropdown">
								<option >Select Yes/No</option>
								<option value="yes">Yes</option>
								<option value="no">No</option>
							</select><br><br>
							<input type="checkbox" required name="check">
							<label> &nbsp;&nbsp;&nbsp;I agree for Terms & Conditions of T&P Cell</label><br><br>
							<button class="ui blue button" type="Submit">Submit</button>
						</form>
					</div>
				</div>
				<div class="column">
					
				</div>
			</div>
	</div>
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
	<script type="text/javascript">
		$('.ui.dropdown').dropdown();
	</script>
</body>
</html>