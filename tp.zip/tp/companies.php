<?php
	include 'authenticate.php';
	if (isset($_SESSION['sid'])) {
		//echo $_SESSION['sid'];
	}else{
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->
	<div class="ui inverted blue buttons stackable menu" style="font-weight: bold;">
		<a href="index.php" class="item" style="cursor: pointer;">Training & Placements Cell</a>
	
		
		<a href="about.php" class="right floated item" style="cursor: pointer;"><b>About T & P</b></a>
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='profile.php' class='item' style='cursor: pointer;'><b>Welcome! ".$_SESSION['sname']."</b></a>";
				echo "<a href='companies.php' class='active item' style='cursor: pointer;'><b>Walkins</b></a>";
				echo "<a href='contact.php' class='item'><b>Contact Us</b></a>";
			?> 
			<a href="logout.php" class="item"><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='contact.php' class='item'><b>Contact Us</b></a>";
				echo "<a href='login.php' class='item' style='cursor: pointer;'><b>Student Login</b></a>";	
			}
		?>
	</div>
	<div class="ui container raised segment">
		<div class="ui blue raised segment header center aligned">List of Companies</div>
			<?php
				$sid=$_SESSION['sid'];
				$sql="select * from students where sid='$sid'";
				$res=$con->query($sql);
				$sdata=$res->fetch_assoc();
				$sql="select * from companies order by date desc";
				$res=$con->query($sql);
				echo "<table class='ui stackable table'>";
				echo "<thead>";
				echo "<th>Company ID</th>";
				echo "<th>Company Name</th>";
				echo "<th>Walkin Date</th>";
				echo "<th>Action</th>";
				echo "</thead>";
				while ($row=$res->fetch_assoc()) {
						$br=array($row['branch']);
						//print_r($br);
						$valid=0;
						foreach ($br as $val) {
							if (strpos($val, $sdata['branch'])!==false) {
								$valid=1;
								break;
							}
						}
						if ($valid==1 && $row['ssc_yop']==$sdata['ssc_yop'] && $row['ssc_gpa']<=$sdata['ssc_gpa'] && $row['puc_yop']==$sdata['puc_yop'] && $row['puc_cgpa']<=$sdata['puc_cgpa'] && $row['engg_cgpa']<=$sdata['engg_cgpa'] && $row['no_of_backlogs']>=$sdata['no_of_backlogs'] && $row['education_gap']>=$sdata['education_gap'] ) {
							if ($row['gender']=="both") { 	

									$s1="select * from applied_list where sid='$sid' and cid=".$row['cid']." and walkin_date='".$row['date']."' and cname='".$row['cname']."'";
									$r1=$con->query($s1);
									if ($r1->num_rows==0) {
										//echo "s";
										echo "<tr><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['date']."</td>

										<td>
											<form action='apply.php' method='post'>
												<input type='hidden' name='cid' value=".$row['cid'].">
												<input type='hidden' name='cname' value=".$row['cname'].">
												<input type='hidden' name='c_folder' value=".$row['c_folder'].">
												<input type='hidden' name='walkin_date' value=".$row['date'].">
												<button type='submit' name='submit' class='ui green button'>Apply</button>
											</form>
										</td>

										</tr>";
									}else{
										echo "<tr><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['date']."</td>

										<td>
											Applied...
										</td>

										</tr>";
									}
									
							}elseif ($row['gender']==$sdata['gender']) {
								$s1="select * from applied_list where sid='$sid' and cid=".$row['cid']." and walkin_date='".$row['date']."' and cname='".$row['cname']."'";
									$r1=$con->query($s1);
									if ($r1->num_rows==0) {
										//echo "s";
										echo "<tr><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['date']."</td>

										<td>
											<form action='apply.php' method='post'>
												<input type='hidden' name='cid' value=".$row['cid'].">
												<input type='hidden' name='cname' value=".$row['cname'].">
												<input type='hidden' name='c_folder' value=".$row['c_folder'].">
												<input type='hidden' name='walkin_date' value=".$row['date'].">
												<button type='submit' name='submit' class='ui green button'>Apply</button>
											</form>
										</td>

										</tr>";
									}else{
										echo "<tr><td>".$row['cid']."</td><td>".$row['cname']."</td><td>".$row['date']."</td>

										<td>
											Applied...
										</td>

										</tr>";
									}
							}
								
						}
						
				}
				echo "</table>";


			?>
	</div>
	
	<div class="ui blue inverted raised segment header center aligned bottom fixed menu">&nbsp;&copy; Copyrights RGUKT-Basar T & P Cell...</div>
</body>
</html>