<?php
//$msg = (isset($_GET['msg'])&&$_GET['msg']== 1?'1':'0');
/*$hostname = "localhost";
$username = "root";
$password = "raghu68";
$database = "tnp";*/

$hostname = "localhost";
$username = "root";
$password = "";
$database = "tnp";
$con = mysqli_connect("$hostname","$username","$password","$database") or die(mysqli_error());
if(!$con){
	echo "Not connected";
}else{
//	echo "connected";
}
?>
