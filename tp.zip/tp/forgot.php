
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->

	<div class="ui blue inverted stackable menu" style="font-weight: bold;">
		<a href="index.php" class="item"><i class="home icon"></i> <b>Training & Placements Cell</b></a>
	</div>
		<center>
			<div class="ui container raised segment">
				 <div class="ui blue centered header">Forgot Password</div>
				 <form class="ui form" method="post" action="#" style="width: 50%;">
				 		<label><b>Student ID</b></label>
				 		<input type="text" name="sid" placeholder="Please Enter ID">
				 		<label><b>Date of Birth</b></label>
				 		<input type="date" name="date" placeholder="Please Select your DOB">
				 		<br><br>
				 		<button type="submit" value="Submit" class="ui blue button">Submit</button>
				 </form>
			</div>
		</center>
</body>
</html>
<?php
	include './db.php';
	
	if (isset($_POST['date']) ) {
		$dob=$_POST['date'];
		//echo $dob;
		$sid=$_POST['sid'];
		$sql="select * from students where dob='$dob' and sid='$sid'";
		$res=$con->query($sql);
		if($res->num_rows>0){
				$row=$res->fetch_assoc();
				//echo $row['dob'];
					?><center>
						<div class="ui container raised segment">
							 <div class="ui blue centered header">Update Password</div>
							 <form class="ui form" method="post" action="#" style="width: 50%;">
							 		<input type="hidden" name="sid" value=<?php echo $row['sid'];?> >
							 		<label><b>New Password</b></label>
							 		<input type="password" name="passwd" placeholder="Enter New Password">
							 		<br><br>
							 		<label><b>Confirm Password</b></label>
							 		<input type="password" name="cpasswd" placeholder="Re-Enter New Password">
							 		<br><br>
							 		<button type="submit" value="Submit" class="ui blue button">Submit</button>
							 </form>
						</div>
					</center>
		<?php
		}else{
				echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Invalid Date..... </div>
                        </div>";
		}
	}

	if(isset($_POST['passwd']) && isset($_POST['cpasswd']) && isset($_POST['sid'])) {
		$psd=$_POST['passwd'];
		$psd1=$_POST['cpasswd'];
		$sid=$_POST['sid'];
		if($psd!=$psd1){
			echo "<center><p>Passwords didn't matched</p></center>";

		}else{
			$sql="update students set password='$psd' where sid='$sid' ";
			//echo $sql;
			$res=$con->query($sql);
			if ($res) {

				  echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:green;'>Password Updated..... </div>
                        </div>";
			}else{
					echo "<div class='ui message'>
                           <div class='center aligned content header' style='color:red;'>Oops something went wrong..... </div>
                        </div>";
			}
		}
	}
?>