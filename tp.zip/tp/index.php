<?php
	include 'authenticate.php';
	if (isset($_SESSION['sid'])) {
		//echo $_SESSION['sid'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training & Placements Cell</title>
	
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/semantic.min.js"></script>
</head>
<body>
	<!-- <div class="ui blue inverted raised segment header centered">Training & Placements Cell</div> -->

	<div class="ui blue inverted stackable menu" style="font-weight: bold;">
		<a href="#" class="item"><i class="home icon"></i> <b>Training & Placements Cell</b></a>
	
		
		
		<?php 
			if (isset($_SESSION['sid'])) {
				echo "<a href='profile.php' class='right floated item'><i class='user icon'></i><b>Welcome! ".$_SESSION['sname']."</b></a>";
				echo "<a href='companies.php' class='item'><i class='child icon'></i><b>Walkins</b></a>";
				echo "<a href='#' class='item'><i class='users icon'></i><b>CRT</b></a>";
			?> 
			<a href='contact.php' class='item'><i class="phone icon"></i><b>Contact Us</b></a>
			<a href="logout.php" class="item"><i class="sign-out icon"></i><b>Logout</b></a>
			<?php
			}else{
				echo "<a href='contact.php' class='right floated item'><i class='phone icon'></i><b>Contact Us</b></a>";
				echo "<a href='login.php' class='item'><b>Student Login</b></a>";	
			}
		?>
		<a href="about.php" class="item"><i class="info circle icon"></i><b>About T & P</b></a>
	</div>
	<!-- if need add flash maqueee here-->
	<div class="ui container">
		<div class="ui raised segment">
			<img src="images/bg.jpg" class="ui image" style="width:1200px;height: 600px;">
		</div>

		<div class="ui three column equal width center aligned stackable grid">
			<div class="column">
				<div class="ui raised segment card">
					<div class="ui blue inverted segment">News & Events</div>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<br>
					<br>
					<a class="item">&nbsp;</a>
					<a class="item"><button class="ui blue button">Read More</button></a>
					<br>
					<a class="item">&nbsp;</a>
				</div>
			</div>
			<div class="column">
				<div class="ui raised segment card">
					<div class="ui blue inverted segment">Companies Schedule</div>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<br><br>
					<a class="item">&nbsp;</a>
					<a class="item"><button class="ui blue button">Read More</button></a>
					<br>
					<a class="item">&nbsp;</a>
				</div>
			</div>
			<div class="column">
				<div class="ui raised segment card">
					<div class="ui blue inverted segment">Latest News</div>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<a href="#" class="item">1dfds</a>
					<br><br>
					<a class="item">&nbsp;</a>
					<a class="item"><button class="ui blue button">Read More</button></a>
					<br>
					<a class="item">&nbsp;</a>
				</div>
			</div>
		</div>
	</div>
	<br><br><br><br>

	<div class="ui raised segment">
		<div class="ui equal width three column stackable grid">
			<div class="column">
				<div class="ui blue centered header">Quick Contacts</div>
				
				<div class="ui centered center aligned items">
					<a href='#' class="item">&nbsp;&nbsp;&nbsp;&nbsp;<i class="phone icon"></i>&nbsp;+91-9999999999</a>
					<a href='#' class="item">&nbsp;&nbsp;&nbsp;&nbsp;<i class="mail icon"></i>&nbsp;tnp@rgukt.ac.in</a>
				</div>
			</div>
			
			<div class="column">
				<div class="ui blue centered header">&nbsp;</div>
				
				<div class="ui centered center aligned items">
					<a class="item">&nbsp;</a>
					<a class="item">&nbsp;</a>
					<a class="item">&nbsp;</a>
				</div>
			</div>
			<div class="column">
				<div class="ui blue centered header"><i class='map marker alternate icon'></i>Address</div>
				
				<div class="ui centered center aligned items">
					
					   	T&P Office<br>
					    RGUKT-Basar<br>
					    Basar (Village & Mandal)<br>
					    Nirmal Dist, Telangana State,504107<br>
					    Fax: +91 08752 243355<br>

				</div>
			</div>
		</div>
	</div>
	<center><div class="ui blue inverted raised segment center aligned header menu">&nbsp; Copyright © 2019, Designed and Developed by Training and Placement Office, RGUKT Basar</div></center>
</body>
</html>
